
- *The pretrained checkpoints can be downloaded ([from here](https://drive.google.com/drive/folders/1aoluekvB_CzoaqGhLutwtJptIOBasl7i?usp=sharing))*


